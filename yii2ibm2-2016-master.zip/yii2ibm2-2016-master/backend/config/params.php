<?php
return [
    'adminEmail' => 'billsofhealth@outlook.com',
];
