<?php

/* @var $this yii\web\View */

$this->title = 'My Yii Application';
?>


<div>
              <script type="text/javascript">
                //do not remove
                var _global_source = "";
                var _global_publisherImpressionPixel = "";
                var _global_publisherClickPixel = "";
                var _g_site = "";
                var _g_platform = "";
                var _global_adUnitType = "";

                var hyperlocal_vars = {

                // REQUIRED PARAMETERS BEGIN
                // ----------------------------------

                apikey: 'kv0rn6ljlx', // publisher id
                visitorid: '', // a unique user id
                // Must provide one or more of lat/long OR city state OR zip.
                location:'', // loc of user request
                // ----------------------------------
                // REQUIRED PARAMETERS END
                // OPTIONAL PARAMETERS
                keywords:'', // keyword or category list describing content
                site:'', // Represents the specific publisher site
                test:'', // '1' for test mode, else live ads will flow through
                source:'30', // Will be provided by ATT if required
                gender:'', // Male is 0, Female is 1
                age:'', // User's age
                income:'', // Integer value from 1 to 10 - see docs for tranches
                edu:'', // Integer value from 0 to 3 - see docs for tranches
                eth:'', // Integer value from 0 to 12 - see docs for tranches
                dma:'', // Designated Market Area - 3 digit code
                marital:'', // 0 for single, 1 for married
                zip:'',
                carrier:'' // Indicates carrier/provider.
                };

                // fill out this function to debug.
                window.renderHyperLocalAdError = function(errorJSON) {
                    alert(errorJSON.message);
                }
              </script>

              <div id="attihyperlocalad"></div>
              <script type="text/javascript" src="http://html5adkit.plusmo.s3.amazonaws.com/popcatv3cdn/1.1/popcat3/js/hyperad2.js"></script>
1
            </div>




<div class="site-index">

    <div class="jumbotron">
        <h1>Congratulations!</h1>

        <p class="lead">You have successfully created your Yii-powered application.</p>

        <p><a class="btn btn-lg btn-success" href="http://www.yiiframework.com">Get started with Yii</a></p>
    </div>

    <div class="body-content">

        <div class="row">
            <div class="col-lg-4">
                <h2>Heading</h2>

                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et
                    dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip
                    ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu
                    fugiat nulla pariatur.</p>

                <p><a class="btn btn-default" href="http://www.yiiframework.com/doc/">Yii Documentation &raquo;</a></p>
            </div>
            <div class="col-lg-4">
                <h2>Heading</h2>

                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et
                    dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip
                    ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu
                    fugiat nulla pariatur.</p>

                <p><a class="btn btn-default" href="http://www.yiiframework.com/forum/">Yii Forum &raquo;</a></p>
            </div>
            <div class="col-lg-4">
                <h2>Heading</h2>

                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et
                    dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip
                    ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu
                    fugiat nulla pariatur.</p>

                <p><a class="btn btn-default" href="http://www.yiiframework.com/extensions/">Yii Extensions &raquo;</a></p>
            </div>
        </div>

    </div>
</div>
