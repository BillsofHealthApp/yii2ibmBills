<?php
use yii\helpers\Html;
?>  

<?=$model->doc_id;?> 
<?=$model->Family;?> 
<?=$model->Cardiac;?>