<?php

use yii\helpers\Html;


/* @var $this yii\web\View */
/* @var $model frontend\models\Npi */

$this->title = Yii::t('app', 'Create Npi');
$this->params['breadcrumbs'][] = ['label' => Yii::t('app', 'Npis'), 'url' => ['index']];
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="npi-create">

    <h1><?= Html::encode($this->title) ?></h1>

    <?= $this->render('_form', [
        'model' => $model,
    ]) ?>

</div>
