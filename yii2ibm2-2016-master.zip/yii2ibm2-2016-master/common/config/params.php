<?php
return [
    'adminEmail' => 'billsofhealth@outlook.com',
    'supportEmail' => 'billsofhealth@outlook.com',
    'user.passwordResetTokenExpire' => 3600,
];
